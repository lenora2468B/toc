We would like to acknowledge previous TOC members and their huge contributions to our collective success: 

* Jonathan Boulle (1/29/2016 - 1/29/2019)
* Bryan Cantrill (1/29/2016 - 1/29/2019)
* Camille Fournier (1/29/2016 - 1/29/2019)
* Benjamin Hindman (1/29/2016 - 1/29/2019)
* Solomon Hykes (1/29/2016 - 3/17/2018)
* Elissa Murphy (1/29/2016 - 10/2/2017)
* Ken Owens (1/29/2016 - 1/29/2019)
* Kelsey Hightower (1/29/2019 - 3/11/2019)
* Quinton Hoole (3/17/2018 - 3/17/2019)
* Alexis Richardson (1/29/2016 - 1/29/2020)
* Joe Beda (1/29/2019 - 1/29/2020) 
* Brian Grant (1/29/2016 - 3/17/2020)
* Jeff Brewer (1/29/2019 - 9/1/2020)
* Katie Gamanji (2/4/2020 - 11/2/2020)
* Brendan Burns (1/29/2019 - 1/29/2021)
* Matt Klein (1/29/2019 - 1/29/2021)
* Xiang Li (1/29/2019 - 1/29/2021)

We thank these members for their service to the CNCF community.
