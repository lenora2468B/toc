This is based off of the [Sandbox Annual Review](https://github.com/cncf/toc/blob/master/process/sandbox-annual-review.md) process. 
- [ ] Is your PR called: [Project name] [year] Annual Review?
- [ ] Did you include a file for <year>-<project name>-annual.md?
- [ ] Did you include a link to your project’s devstats page?
- [ ] Did you include a link to your MAINTAINERS file?
- [ ] What do you know about adoption? Is there an existing ADOPTERS file?
- [ ] Did you include any previous goals?
- [ ] Are your current goals listed?
- [ ] Did you include requests from the CNCF?
- [ ] Do you want to start the process for incubation? (This is a separate process) 
